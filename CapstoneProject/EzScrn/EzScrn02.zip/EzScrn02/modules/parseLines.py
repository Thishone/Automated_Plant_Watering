
from modules import globalData as GD
import sys
import time


# these values will increment so there is no accidental overlap
GD.elTop = 0
GD.elLeft = 0

# these values will only change if there is input
#~ GD.elWidth = 40
#~ GD.elHeight = 40

# values for parsing
GD.elParts = ['type', 'name', 'size', 'tleft', 'bg', 'fg', 'range', 'text', 'value']


GD.compiling = False
GD.starting = True
GD.startTime = time.time()

GD.arduinoVal = {}

#============================

def parseLine(sD):
		# this is the first assessment
	lineParts = sD.split(',')
	lineParts[0] = lineParts[0].strip()
	
		#check that we start with a newScrn
	if GD.starting == True:
		if lineParts[0] == "+newScrn":
			GD.starting = False
		else:
			return "X"	# badStart
	
	if GD.compiling == True and (time.time() - GD.startTime > 5):
		GD.compiling = False	# waiting too long for +endScrn
		return "T"	# compile timeout
	
		# deal with compiling a screen display
	if lineParts[0] == "+newScrn":	#note this acts whether or not already compiling
		GD.compiling = True
		GD.parsedLines = []			# will hold the lines to make a screen
		GD.screenLine = 0			# counter for lines
		GD.lineNames = {}			# will allow indexing the LIST by name
		GD.outputList = []			# will hold the names of the DIVs for output to the screen - in order
		GD.inputList = []			# will hold data for all input elements FROM the screen - in order
		GD.zindex = 0				# for stacking order of elements
		GD.startTime = time.time()
		
		# this is here so the +startScrn line will be compiled
	if GD.compiling == True:
		compileLine(sD);
		
			# this is here so the +endScrn line will have been compiled
		if lineParts[0] == "+endScrn":
			GD.compiling = False
			return "S"	# doScreen
		else:
			return "C"
	else:
		if lineParts[0] == "+btn":
			return "B"
		else:
				# deal with displaying text
			return "D"

#==========================
	# take a line, find approved pieces and make them into a DICT{}
	#   there will be an entry in GD.parsedLines for every screen element
def compileLine(sD):
	lineEls = {}
		# create entries for all possible parts
	for eP in GD.elParts:
		lineEls[eP] = ''
		# split the data and replace + with type=
	lineParts = sD.split(',')
	lineParts = [x.strip() for x in lineParts]
	lineParts[0] = lineParts[0].replace('+', 'type=') 
	
		# update the entries from the data received
	for lp in lineParts:
		lpEls = lp.split('=')
		
		for eP in GD.elParts:
			if lpEls[0] == eP:
				lineEls[eP] = lpEls[1]
	#~ print lineEls
	#~ GD.parsedLines.append(lineEls)
	
		# need a DICT that allows indexing into LIST
		#  need LIST because it retains the order
	elName = lineEls['name']
	if elName == '':
		elName = 'XX' + str(GD.screenLine)
		lineEls['name'] = elName
	GD.parsedLines.append(lineEls)
	
	GD.lineNames[elName] = str(GD.screenLine)
	GD.screenLine += 1
	#~ print GD.parsedLines
	#~ print "LINEnames "
	#~ print GD.lineNames
	


