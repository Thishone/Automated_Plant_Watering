def href_params(link, **pars):
	# this takes a hash of params and reformats them into a suitable string

	strn = " href=" + link +"?"
	for k,v in pars.iteritems():
		strn = strn + k + "=" + str(v) + "&"

	# drop the final &
	strn = strn.rstrip('&')
	
	print "=======HREF STRING " + str
	return strn

# what Rails produces
#<a href="/cab/control?cmd=pwr&amp;loco=1&amp;val=6&amp;oldvals[brk1]=0&amp;oldvals[pwr1]=0&amp;oldvals[dir1]=FWD&amp;oldvals[brk2]=0&amp;oldvals[pwr2]=0&amp;oldvals[dir2]=FWD" data-method="post" rel="nofollow">SP6</a>

def test():
	return 'This is a test'

#===============

def button_h(hsh):

	# <INPUT TYPE="BUTTON" VALUE="Home Page" ONCLICK="window.location.href='http://www.computerhope.com'">
	#  <button type="button">Click Me!</button> 
	strn = "<input type=\"button\" "
	strn = strn + hsh_conv(**hsh)
	strn = strn + ">"
	#~ strn = strn + 'TEST'
	#~ strn = strn + '</button>'
	return strn  

#===============

def input_text_h(hsh):

	# <input type="text" name="fname">
	strn = "<input type = \"text\" "
	strn = strn + hsh_conv(**hsh)
	strn = strn + ">"
	return strn


#===============

def input_hidden_h(hsh):

	# <input type="hidden" name="Language" value="English">
	strn = "<input type = \"hidden\" "
	strn = strn + hsh_conv(**hsh)
	strn = strn + ">"
	return strn


#===============

def form_h(hsh):

	strn = "<form "  
	strn = strn + hsh_conv(**hsh)
	strn = strn + ">"
	return strn

#===============

def radio_button_h(hsh):
	#<input type="radio" name="sex" value="male">Male<br>
	strn = "<input type= \"radio\" "
	strn = strn  + hsh_conv(**hsh)
	strn = strn + ">"
	return strn

#===============

def hsh_conv(**hsh):
	strn = ""
	for k,v in hsh.iteritems():
		strn = strn + k +"=\"" + str(v) + "\"  "

	return strn

