from ArduinoComms import arduinoComms as AC
from modules import globalData as GD

import threading
import time
import sys

from modules import globalData as GD
from modules import parseLines as PL
from modules import genHtml as GH

GD.inputData = ""
GD.threadRun = True
GD.keyboardInterrupt = False
GD.checkDelay = 0.1 # seconds

#========================

def listCommPorts():
	print "Select Comm Port"
	GD.listSP = AC.listSerialPorts()

#=========================

def setupConnection():
	print "Setup Connection"
		# open connection
	try:
		AC.setupSerial(GD.serPort, 115200)
		print "Serial Port Open"
			# start listener Thread
		listenForData()
	except Exception as Ex:
		print "failed to open serial port"
		print type(Ex)

#=========================

def dataFromBrowser(params):
	print "PARAMS ..."
	for k, v in params.items():
		print k + " " + v
	print "...params"
		# params will have data from all of the inputs
		# need to present them to the Arduino in the correct order
	arduinoText = ''
	for inp in GD.inputList:
		arduinoText += str(params[inp]) + ","
	arduinoText += str(params['buttonVal'])
	print "ARD TXT " + arduinoText
	AC.sendToArduino(arduinoText)

#=========================

#======================

# global variables for module

GD.inputData = ""
GD.threadRun = True
GD.keyboardInterrupt = False
GD.checkDelay = 0.1 # seconds

#======================

def checkForData():

	print "Starting to Listen"
	while GD.threadRun == True and GD.keyboardInterrupt == False:
		#~ if GD.replySent == True:
		if GD.replyReady == False:
			print "RECEIVING"
			dataRecvd = AC.recvFromArduino(2)

			if dataRecvd == '<<' or dataRecvd == '>>':
				print "Arduino Timeout " + dataRecvd
			else:
				print "Data Received " + dataRecvd
						# figure out what we received
				parseResult = PL.parseLine(dataRecvd)
				print "PRES " + parseResult

						# did not start with newScrn
				if parseResult == 'X':
					badStart()
						# data for display
				elif parseResult == 'D':
					GH.displayLine(dataRecvd)
					#~ GD.replySent = False
						# create a new screen
				elif parseResult == 'B':
					GH.updateBtn(dataRecvd)
					#~ GD.replySent = False
				elif parseResult == 'S':
					GH.genScreen()
					#~ GD.replySent = False
				else:
					pass
	print "Finished Listening"
	GD.replyReady = True	# to allow a reply to the long poll
	AC.closeSerial()


#======================

def listenForData():
	t = threading.Thread(target=checkForData)
	t.daemon = True
	t.start()

#======================

def stopListening():

	GD.threadRun = False
	time.sleep(GD.checkDelay + 0.1) # allow Thread to detect end

#========================

def badStart():
	stopListening()
	print "Stopping ... No Initial Screen"
	AC.closeSerial()
	sys.exit()

#============================
