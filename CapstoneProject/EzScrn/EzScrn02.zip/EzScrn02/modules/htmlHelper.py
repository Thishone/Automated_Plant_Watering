from modules import globalData as GD

#============================

def fn_name(pL):
	val = ''
	try:
		val = pL['name']
	except:
		pass
	return val

#============================

def fn_ID(pL):
	idLine = ''
	try:
		val = pL['name']
		idLine = "id='" + val + "' "
	except:
		pass
	return idLine

#============================

def getSizeVals(pL):
	
			#set temporary values to indicate missing values
	GD.tempWidth = -1 
	GD.tempHeight = -1
	GD.tempTop = -1
	GD.tempLeft = -1 

	valBits = pL['size'].split('x')
	try:
		GD.tempWidth = abs(int(valBits[0]))
	except:
		pass
	try:
		GD.tempHeight = abs(int(valBits[1]))
	except:
		pass

	valBits = pL['tleft'].split('x')
	try:
		GD.tempLeft = abs(int(valBits[0]))
	except:
		pass
	try:
		GD.tempTop = abs(int(valBits[1]))
	except:
		pass


#============================

def fn_newSize(pL):
		# only called by fn_newScrn
		# set default values
	GD.screenTop = 0
	GD.screenLeft = 0
	#~ GD.screenWidth = 48
	#~ GD.screenHeight = 40
	
		# see if there are new values
	getSizeVals(pL)
	
	if GD.tempTop > -1:
		GD.screenTop = GD.tempTop
	if GD.tempLeft > -1:
		GD.screenLeft = GD.tempLeft
	if GD.tempWidth > -1:
		GD.screenWidth = GD.tempWidth
	if GD.tempHeight > -1:
		GD.screenHeight = GD.tempHeight

		# set values for use in fn_style()
	GD.elTop = GD.screenTop
	GD.elLeft = GD.screenLeft
	GD.elWidth = GD.screenWidth
	GD.elHeight = GD.screenHeight

#============================


def fn_checkSize(pL):
	
		# see if there are new values
	getSizeVals(pL)
		
		# now calculate appropriate values
		# the minimum position values will be screenTop and screenLeft - they will be set at 0,0 for a new screen
		# the natural place for a new element would be 
		#	oldTop + oldHeight + 1  and oldLeft   -- this puts them one under the other with a line between them
		# the max position values will be (screenTop + screenHeight) and (screenleft + screenWidth)
		#			how are they derived ? ? ?
		# the max width and height will be
		# screenRight - newLeft and screenBottom - newTop
	
	scrnBottom = GD.screenTop + GD.screenHeight
	scrnRight = GD.screenLeft + GD.screenWidth
	
		# use default values for missing values
	if GD.tempTop < 0:
		GD.tempTop =  GD.elTop + GD.elHeight + 1
	if GD.tempLeft < 0:
		GD.tempLeft = GD.elLeft
	if GD.tempWidth < 0:
		GD.tempWidth = GD.elWidth
	if GD.tempHeight < 0:
		GD.tempHeight = GD.elHeight
	
		# deal with limits and set element values for fn_style()
	GD.elTop = max(GD.tempTop, GD.screenTop + 1)
	GD.elLeft = max(GD.tempLeft, GD.screenLeft)
	maxRemWidth = scrnRight - GD.tempLeft
	maxRemHeight = scrnBottom - GD.tempTop
	GD.elWidth = min(GD.tempWidth, maxRemWidth)
	GD.elHeight = min(GD.tempHeight, maxRemHeight)
	
	
#=================================

def fn_style(pL, scrVal = 'noScroll'):
	
	if GD.newScrnDesign == True: # set in fn_newScrn
		fn_newSize(pL)
	else:
		fn_checkSize(pL)
	
	styleLine = " style='position: absolute;"
	#~ styleLine +=  "z-index: " + str(GD.zindex) + "; "
	if scrVal == 'scroll':
		styleLine += 'overflow: auto; '

	styleLine += "width: " + str(GD.elWidth * GD.pxChar) + "px; height: " + str(GD.elHeight * GD.pxChar) + "px; "
	
	styleLine += "left: " + str(GD.elLeft * GD.pxChar) + "px; top: " + str(GD.elTop * GD.pxChar) + "px; "

	val = pL['bg']
	if val != '':
		GD.elBg = val
	else:
		pL['bg'] = GD.elBg

	lName = pL['name']
	lNum = GD.lineNames[lName]

	styleLine += "background-color:{{ GD.parsedLines[" + str(lNum) + ']["bg"] }}; '
	

	val = pL['fg']
	if val != '':
		GD.elFg = val
	else:
		pL['fg'] = GD.elFg
	#~ styleLine += "color: " + GD.elFg + "; " # COME BACK
	styleLine += "color:{{ GD.parsedLines[" + str(lNum) + ']["fg"] }}; '
	styleLine += "'"
	return styleLine


#============================

def fn_form():
	htmlLine = "<form id='arduinoForm'>"
	htmlLine += "\n<input type = 'hidden' name='buttonVal'  value=''  >"
	return htmlLine

#============================

def fn_newScrn(pL):

	GD.newScrnDesign = True
	
	htmlLine = "% from modules import globalData as GD\n\n"
	htmlLine += "<div id='arduinoDiv'"
	htmlLine += fn_style(pL)
		# this div will be closed later
	htmlLine += " >\n"
	htmlLine += fn_form()
	
	GD.newScrnDesign = False
	
	return htmlLine

#============================

def fn_endScrn(pL):
	htmlLine = "</form>\n"
	htmlLine += "</div>"
	return htmlLine


#=============================

def fn_tOut(pL):
		# <div id='name' style='   '> {{ GD.arduinoVal[name] }} </div>

	htmlLine = '<div '

	divNam = fn_name(pL)
	GD.outputList.append(divNam)
	htmlLine += fn_ID(pL)

	htmlLine += fn_style(pL, 'scroll')
	
	htmlLine += " >"
	htmlLine += " {{ GD.arduinoVal['"
	#~ varName = nxtVar()	# just in case none has been defined

	varName = 'var0'
	try:
		varName = pL['name']
	except:
		pass

	varVal = ''
	try:
		varVal = pL['val']
	except:
		pass

	GD.arduinoVal[varName] = varVal
	
	print "GDVAR " + varName + "  " + str(varVal)

	htmlLine += varName
	htmlLine += "'] }} "
	htmlLine += "</div>"
	
	return htmlLine


#=============================

def fn_tInW(pL):
		#<input type="text" id="name" value="value">
	htmlLine = "<input type='text' "
	htmlLine = fn_remInput(pL, htmlLine)
	return(htmlLine)

#============================

def fn_tInI(pL):
		#<input type="text" id="name" value="value">
	htmlLine = "<input type='text' onchange='inputClick(event)' "
	htmlLine = fn_remInput(pL, htmlLine)
	return(htmlLine)

#=============================

def fn_remInput(pL, htmlLine):

	inNam = fn_name(pL)
	GD.inputList.append(inNam)
	htmlLine += fn_ID(pL)
	
	try:
		val = pL['name']
		htmlLine += "name='" + val + "' "
	except:
		pass
	
	try:
		val = pL['value']
		htmlLine += "value='" + val + "' "
	except:
		pass
	htmlLine += fn_style(pL)
	htmlLine += ">"
	return htmlLine

#============================

def fn_btn(pL):
		# <button type="button">Click Me!</button> 
		# <input type="button" value="List Serial Ports"  id="LSP"  onclick="listSerial()"  name="LSP"  >
	htmlLine = "<input type='button' onclick='buttonClick(event)' "
	htmlLine = fn_remButton(pL, htmlLine)
	return htmlLine

#============================

def fn_quit(pL):
	htmlLine = "<input type='button' onclick='buttonQuit()' "
	htmlLine = fn_remButton(pL, htmlLine)
	return htmlLine

#============================

def fn_remButton(pL, htmlLine):

	htmlLine += fn_ID(pL)
	try:
		val = pL['name']
		htmlLine += "value='" + val + "' "
	except:
		pass
	htmlLine += fn_style(pL)
	htmlLine += ">"

	return htmlLine
	
#============================

def getRangeVals(pL):

	
	if 'range' in pL:
		print "RANGE FOUND"
		valBits = pL['range'].split('x')
		if len(valBits) == 4:
			try:
				GD.rMin = abs(int(valBits[0]))
			except:
				pass
			try:
				GD.rMax = abs(int(valBits[1]))
			except:
				pass
			try:
				GD.rVal = abs(int(valBits[2]))
			except:
				pass
			try:
				GD.rStep = abs(int(valBits[3]))
			except:
				pass
		else:
			print "INVALID RANGE FOR SLIDER"

#============================

def fn_slid(pL):
	htmlLine = "<input type='range' onchange='noButton()' "
	getRangeVals(pL)
	htmlLine += "min='" + str(GD.rMin) + "' " 
	htmlLine += "max='" + str(GD.rMax) + "' " 
	htmlLine += "val='" + str(GD.rVal) + "' " 
	htmlLine += "step='" + str(GD.rStep) + "' " 

	htmlLine = fn_remInput(pL, htmlLine)
	
	return htmlLine



