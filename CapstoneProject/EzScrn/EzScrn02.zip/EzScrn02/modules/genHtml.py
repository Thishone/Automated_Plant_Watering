from modules import globalData as GD
from modules import htmlHelper as HH

GD.elTypes = ['newScrn','endScrn','tOut','tInI','tInW','btn', 'slid', 'quit']

#====================

def displayLine(sD):
	print "DISPL LINE"
	numOutDivs = len(GD.outputList)
	defaultDiv = GD.outputList[numOutDivs - 1]	# the last one entered
		# now see if a specific div has been chosen
	sdParts = sD.split(",")
	useDiv = defaultDiv
	print "DEFAULTDIV " + useDiv
	action = '+'
	numSdParts = len(sdParts)
	if numSdParts > 1:
		lenPart0 = len(sdParts[0]) + 1		# to also exclude the comma
		sD = sD[lenPart0:]		# drop the first part
		
		sdParts[0] = sdParts[0].strip()
		if sdParts[0][0] == '-':
			action = '-'
		divName = sdParts[0][1:]	# drop the + or -
			# check for valid divName
		if divName in GD.arduinoVal:
			useDiv = divName
		
		# replace LF with <br>
	sD = sD.replace("\r\n","\n")
	sD = sD.replace("\n\r","\n")
	sD = sD.replace("\n", "<br>")
	if action == '-':
		GD.arduinoVal[useDiv] = sD
	else:
		GD.arduinoVal[useDiv] += sD
			# GD.arduinoVal is a DICT from which the DIVs in the view scrn0 are populated
			# 	there will be an item in the DICT for each DIV
		
	GD.displayData = "Display Line" + sD
	GD.replyReady = True

#====================

def updateBtn(sD):
	
	#~ BUT BUT BUT --- JqUERY ONLY UPDATES THE divS
	
	
		# just changes the button background colour
		# valid text is name='btnA',bg=orange
	print "UPDATE BUTTON"
	#~ print "SD BTN " + sD # SD BTN +btn, name=btnA, bg=orange
	#~ return
	sdParts = sD.split(",")
	numSdParts = len(sdParts)
	lNum = 0
	try:
		nameSplit = sdParts[1].split("=")
		bName = nameSplit[1].strip()
		if bName in GD.lineNames:
			print "BTN FOUND"
			lNum = int(GD.lineNames[bName])
			try:
				colourSplit = sdParts[2].split("=")
				print "CSPLIT0 " + colourSplit[0]
				if colourSplit[0].strip() == 'bg':
					GD.parsedLines[lNum]['bg'] = colourSplit[1]
			except:
				pass
	except:
		pass
	GD.replyReady = True
		

#====================

def genScreen():
	print "GEN SCREEN"
	
	completeHtml = ''
	for pL in GD.parsedLines:
		mH = makeHtml(pL)
		if mH:
			completeHtml += mH
			completeHtml += '\n\n'
	completeHtml += "% if GD.layout != 'none':\n"
	completeHtml += "  %rebase layout \n"

	GD.displayData = "Display Screen\n" + str(completeHtml)
	tplFile = open("./views/scrn0.tpl", "w" )
	tplFile.write(completeHtml)
	tplFile.close()
	
	GD.replyReady = True


#============================
	#take a line in DICT{} form and generate HTML
	#now we can limit ourselves to approved elements
	#  and in the order of our choosing
def makeHtml(pL):
	# first, the type
	lineHtml = ''
	if 'type' in pL:		# in case there is no item called 'type'
		if pL['type'] in GD.elTypes:		# check for valid identifier
			GD.zindex += 1
			if pL['type'] == 'newScrn':
				lineHtml = HH.fn_newScrn(pL)
			if pL['type'] == 'endScrn':
				lineHtml = HH.fn_endScrn(pL)
			if pL['type'] == 'tOut':
				lineHtml = HH.fn_tOut(pL)
			if pL['type'] == 'tInI':
				lineHtml = HH.fn_tInI(pL)
			if pL['type'] == 'tInW':
				lineHtml = HH.fn_tInW(pL)
			if pL['type'] == 'btn':
				lineHtml = HH.fn_btn(pL)
			if pL['type'] == 'slid':
				lineHtml = HH.fn_slid(pL)
			if pL['type'] == 'quit':
				lineHtml = HH.fn_quit(pL)
		else:
			print "UNKNOWN ELEMENT TYPE " + pL['type']

	return lineHtml

#============================
