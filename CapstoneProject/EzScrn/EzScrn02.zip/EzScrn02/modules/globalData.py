
# server IP address
# serverIP = '127.0.0.1'
serverIP = '127.0.0.1'
#~ serverIP = '192.168.240.1'

serverPort = 8085

#===========================

# set this to the type of board you are using
#   options are 'Leonardo'  'Yun'   'Other'
#   it signals the need for special reset processes for the Leonardo and Yun
arduinoBoard = 'Other'

#===========================

# default values for screen design
# measurements in characters
# screen size
screenWidth = 40
screenHeight = 30

# element size
elWidth = 10
elHeight = 4

# number of pixels per character for absolute positioning
pxChar = 12

# colours
elBg = 'green'
elFg = 'black'

# range values for slider
rMin = 0 
rMax = 10
rVal = 5
rStep = 1 

#===========================