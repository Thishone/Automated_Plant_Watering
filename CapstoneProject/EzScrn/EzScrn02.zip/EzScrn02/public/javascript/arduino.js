
//~ ======================================== 
//~ For use with JQuery
//~ Note the $.post is just a subset of $.ajax
//~ 

var initialLoad = true;

// if this is not the master browser we need to jump straight to getData()
$(document).ready(function() {
	var ckk = $.cookie('idNum');
	//~ alert(ckk);
	if (ckk == 'slave') {
		if (initialLoad == true) {
			initialLoad = false;
			getData();
		}
	}
});

function listSerial() {
	var params = $('#serialPortForm').serialize();
	$.ajax({
		url: '/listSerial',
		type: 'post',
		data: params,
		success: function (response){
			$('#contentDiv').html(response);
		}
	});
};


function startInterface() {
	var params = $('#serialPortForm').serialize();
	$.ajax({
		url: '/startInterface',
		type: 'post',
		data: params,
		success: function (response){
			$('#contentDiv').html(response);
			getData();
		}
	});
};

function buttonQuit() {
	$('input[name="buttonVal"]').val('Quit');
		var params = $('#arduinoForm').serialize();
		//~ alert(params);
		$.ajax({
			url: '/Quit',
			type: 'post',
			data: params,
			success: function (response) {
				var dump = response;
			}
	});
};

function noButton() {
	$('input[name="buttonVal"]').val('x');
	//~ btnVal = 'x';
	sendData();
};

function buttonClick(event){
	$('input[name="buttonVal"]').val(event.target.id);
	//~ alert("buttonClick");
	sendData();
};

function inputClick(event) {
	$('input[name="buttonVal"]').val('nn');
	sendData();
};

function sendData() {
	var params = $('#arduinoForm').serialize();
	//~ alert(params);
	$.ajax({
		url: '/fromBrowser',
		type: 'post',
		data: params,
		success: function (response) {
			var dump = response;
				// clear all input boxes
			$("#arduinoDiv").find('input:text').val(''); 
		}
	});
};



function getData() {
	$.ajax({
		url: '/toBrowser',
		type: 'get',
		success: function (response){
			if (response != "ServerStop") {
					//~ iterate over the DIVs 
				$("#arduinoDiv div").each(function( i ) {
					var rrr = $(response).find('#' + this.id).text();
					$('#' + this.id).html(rrr);
				});
					//~ iterate over the input buttons
				$("#arduinoForm input[type='button']").each(function( i ) {
					var bbb = $(response).find('#' + this.id).css('background-color');
					//~ alert(bbb);
					$('#' + this.id).css('background-color', bbb);
				});
				setTimeout(getData, 200);	// max of 5 calls per second
			}
		}
	});
};


