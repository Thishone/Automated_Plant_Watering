import sys
sys.path.append("./lib") 

from lib.bottle import route, post, get, run, template, request, response, static_file
from modules import mainController as mC
from modules import globalData as GD


	# global for Thread interaction
GD.replyReady = False
	# to distinguish first connection from the others
GD.numConnected = 0

#===========================

@route('<path:path>')
def server_static(path):
	print "PATH"
	return static_file(path, root='./public')
	# path is relative to directory containing this file

#===========================


@route('/')
@route('/start')
def starting():
	print "STARTING"
	if GD.numConnected == 0:
		print "MASTER"
		GD.numConnected += 1
		response.set_cookie('idNum', 'master')
		mC.listCommPorts()
		GD.layout = 'layout'
		return template('selectPort')
	else:
		print "SLAVE"
		response.set_cookie('idNum', 'slave')
		GD.layout = 'layout'
		return template('scrn0')

#===========================


def startingXX():
	print "STARTING"
	if request.get_cookie('idNum') == None:
		GD.numConnected += 1
		response.set_cookie('idNum', str(GD.numConnected))
		if GD.numConnected > 1:
			GD.layout = 'layout'
			return template('scrn0')
		else:
			mC.listCommPorts()
			GD.layout = 'layout'
			return template('selectPort')

#===========================

@post('/listSerial')
def listSerial():
	print "LIST SERIAL"
	mC.listCommPorts()
	print "CONTINUING"
	GD.layout = 'none'
	return template('selectPort')

#===========================


@post('/startInterface')
def startInterface():
	print "START INTERFACE"
	GD.serPort = request.params.listSP
	if GD.serPort != None:
		mC.setupConnection()
	GD.replyReady = False
	while(GD.replyReady == False):
		pass
	GD.layout = 'none'
	return template('scrn0')

#===========================

@post('/fromBrowser')
def takeDataFromBrowser():
	print "DATA FROM BROWSER"
	print "COOKIE ID " + request.get_cookie('idNum')
	mC.dataFromBrowser(request.params)
	return 'BLANK'

#===========================


@get('/toBrowser')
def sendDataToBrowser():
	print "LONG POLL REQUEST"
	print "COOKIE ID " + request.get_cookie('idNum')
	if GD.keyboardInterrupt == True:
		print "Returning ServerStop"
		return "ServerStop"
	else:
		GD.replyReady = False
		while(GD.replyReady == False):
			pass
		GD.layout = 'none'
		print "LONG POLL REPLY"
		return template('scrn0')

#===========================

@post('/Quit')
def closeServer():
	print "QUIT PRESSED"
	GD.stopServer = True
	return "Closing Down"

#===========================

run(host=GD.serverIP, port=GD.serverPort, server='cherrypy')


#===========================
